package restu.rebootoption;


import android.os.Bundle;
import android.support.v4.app.Fragment;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.content.Context;
import android.os.AsyncTask;
import android.widget.Button;
import android.widget.Toast;
import android.widget.ImageView;
import android.view.animation.Animation;
import android.view.animation.AnimationUtils;
import libsuperuser.Shell;


/**
 * A simple {@link Fragment} subclass.
 */
public class HomeFragment extends Fragment {


    public HomeFragment() {
        // Required empty public constructor
    }


    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
        // Inflate the layout for this fragment
        View root = inflater.inflate(R.layout.fragment_home, container, false);

        /** ImageView Animation :) */
        final ImageView zoom = (ImageView) root.findViewById(R.id.imageView);
        final Animation zoomAnimation = AnimationUtils.loadAnimation(getActivity(), R.anim.zoom);
        zoom.startAnimation(zoomAnimation);

        /** Reboot Option :D. */

        Button reboot,recovery,poweroff,systemui;

        systemui = (Button) root.findViewById(R.id.btn_ui);
        recovery = (Button) root.findViewById(R.id.btn_recovery);
        reboot = (Button) root.findViewById(R.id.btn_reboot);
        poweroff = (Button) root.findViewById(R.id.btn_off);

        systemui.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                (new StartUp()).setContext(v.getContext()).execute("systemui");


            }
        });
        reboot.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                (new StartUp()).setContext(v.getContext()).execute("reboot");


            }
        });
        recovery.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                (new StartUp()).setContext(v.getContext()).execute("recovery");

            }
        });
        poweroff.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                (new StartUp()).setContext(v.getContext()).execute("poweroff");

            }
        });


        return root;
    }

    private class StartUp extends AsyncTask<String,Void,Void> {


        private Context context = null;
        boolean suAvailable = false;
        public StartUp setContext(Context context) {
            this.context = context;
            return this;
        }

        @Override
        protected Void doInBackground(String... params) {
            suAvailable = Shell.SU.available();
            if (suAvailable) {

                // suResult = Shell.SU.run(new String[] {"cd data; ls"}); Shell.SU.run("reboot");
                switch (params[0]){
                    case "reboot"  : Shell.SU.run("reboot");break;
                    case "recovery"   : Shell.SU.run("reboot recovery");break;
                    case "poweroff": Shell.SU.run("reboot -p");break;
                    //case "sysui"   : Shell.SU.run("am startservice -n com.android.systemui/.SystemUIService");break;
                    case "systemui"   : Shell.SU.run("pkill com.android.systemui");break;
                }
            }
            else
                Toast.makeText(getActivity(), "Your Phone Is Not Detected Root Access ", Toast.LENGTH_SHORT).show();

            return null;
        }




    }
}

